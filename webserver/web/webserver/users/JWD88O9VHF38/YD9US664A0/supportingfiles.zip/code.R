retJSON <- '{
 \"msg\": "recurrent!"
}'
write(retJSON, file="out.json")