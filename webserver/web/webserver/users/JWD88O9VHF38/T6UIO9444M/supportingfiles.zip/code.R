retJSON <- '{
\"msg\": "I am demo"
}'
write(retJSON, file="out.json")