retJSON <- '{
\"msg\": "I am test"
}'
write(retJSON, file="out.json")