retJSON <- '{
 \"msg\": "I am a test"
}'
write(retJSON, file="out.json")