retJSON <- '{
  \"msg\": "I am Ali"
}'
write(retJSON, file="out.json")