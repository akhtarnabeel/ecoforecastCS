retJSON <- '{
 \"msg\": "In this"
}'
write(retJSON, file="out.json")