retJSON <- '{
  \"msg\": "I am Nabeel"
}'
write(retJSON, file="out.json")