retJSON <- '{
\"msg\": 3
}'
write(retJSON, file="out.json")