retJSON <- '{
  \"msg\": "I am here"
}'
write(retJSON, file="out.json")