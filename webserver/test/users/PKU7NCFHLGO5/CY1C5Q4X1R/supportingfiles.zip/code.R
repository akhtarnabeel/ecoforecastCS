library(MODISTools)

library(rjags)
library(runjags)