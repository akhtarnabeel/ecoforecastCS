#!/bin/bash
#echo "hi"
cd /var/www/html; ./wsk -i action invoke demo --blocking --result